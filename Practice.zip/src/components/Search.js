import React from "react";

export default function Search() {
  return (
    <section id="Search" className="py-5 text-center">
      <div className="primary-overlay">
        <div className="container">
          <div className="row">
            <div className="col-lg-3 col-md-12"></div>
            <div className="col-lg-6 col-md-12">
              <img className="mainimg" src="./assets/img/diit.png" alt="DIIT" />
              <br></br>
              <div className="">
                <form action="https://www.google.com/search" method="GET">
                  <input
                    type="search"
                    className="input-field"
                    name="q"
                    placeholder="Search Anything"
                    aria-label="Search"
                    aria-describedby="search-addon"
                  />
                  <button className="btn btn-outline-success" type="submit">
                    Search
                  </button>
                </form>
              </div>
            </div>
            <div className="col-lg-3 col-md-12"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
