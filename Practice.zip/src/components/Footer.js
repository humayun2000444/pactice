import React from "react";

export default function Footer() {
  return (
    <section id="Footer" className="py-2 text-center bg-light">
      <div className="primary-overlay">
        <div className="container">
          <div className="row">
            <div className="col-lg-4 col-md-12"></div>
            <div className="col-lg-4 col-md-12">
              <h6>Design By HUMAYUN AHMED © 2022</h6>
            </div>
            <div className="col-lg-4 col-md-12"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
