import React from "react";

export default function Schedule() {
  return (
    <section id="Schedule" className="py-5 text-center">
      <div className="primary-overlay">
        <div className="container">
          <div className="row">
            <div className="borderc col-lg-4 col-md-12">
              <h4 className="Schedule">Shedule And Appoinment</h4>
              <ui>
                <li className="booking">
                  Sunday 10:00am - 12:00pm
                  <button type="button" className="btn btn-outline-secondary">
                    Book Now
                  </button>
                </li>
                <li className="booking">
                  Tuesday 01:00pm - 04:00pm
                  <button type="button" className="btn btn-outline-secondary">
                    Book Now
                  </button>
                </li>
                <li className="booking">
                  Thursday 10:00am - 12:00pm
                  <button type="button" className="btn btn-outline-secondary">
                    Book Now
                  </button>
                </li>
                <li className="booking">
                  Friday 02:00pm - 08:00pm
                  <button type="button" className="btn btn-outline-secondary">
                    Book Now
                  </button>
                </li>
                <br></br>
              </ui>
              <button type="button" className="btn btn-secondary">
                See More
              </button>
            </div>
            <div className="borderc col-lg-4 col-md-12">
              <h4 className="emargency">Emargency Shedule</h4>
              <p>
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make a type specimen book. It has
                survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release of Letraset sheets
                containing <br></br>
                <br></br>
                <button type="button" className="btn btn-secondary">
                  See More
                </button>
              </p>
            </div>
            <div className="borderc col-lg-4 col-md-12">
              <h4 className="view">View Past Records</h4>
              <p>
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make a type specimen book. It has
                survived not only five centuries, but also the leap into
                electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release of Letraset sheets
                containing <br></br>
                <br></br>
                <button type="button" className="btn btn-secondary">
                  See More
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
