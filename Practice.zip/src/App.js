import "./App.css";
import Footer from "./components/Footer";
import Navebar from "./components/Navebar";
import Schedule from "./components/Schedule";
import Search from "./components/Search";

function App() {
  return (
    <>
      <Navebar />
      <Search />
      <Schedule />
      <Footer />
    </>
  );
}

export default App;
